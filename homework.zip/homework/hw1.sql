SELECT 'ФИО: Атаев Илья';
--Задание 1.1
SELECT * FROM ratings LIMIT 10;
--Задание 1.2
SELECT imdbid, movieid FROM links WHERE imdbid LIKE '%42' AND movieid BETWEEN 100 AND 1000 LIMIT 10;
--Задание 2.1
SELECT * FROM links INNER JOIN ratings ON links.movieid=ratings.movieid WHERE ratings.rating=5 LIMIT 10;
--Задание 3.1
SELECT COUNT(DISTINCT links.movieid) FROM links LEFT JOIN ratings ON links.movieid=ratings.movieid WHERE ratings.rating IS NULL;
--Задание 3.2
SELECT userid, AVG(rating) as ar FROM ratings GROUP BY userid HAVING AVG(rating)>3.5 ORDER BY AVG(rating) DESC LIMIT 10;
--Задание 4.1
SELECT imdbid FROM links INNER JOIN ratings ON links.movieid=ratings.movieid WHERE ratings.rating>(SELECT AVG(rating) FROM ratings) LIMIT 10;
--Задание 4.2
WITH lol_tbl AS (SELECT userid, COUNT(rating) as cnt, AVG(rating) as aver FROM ratings GROUP BY userid) SELECT AVG(aver) FROM lol_tbl WHERE cnt>9;