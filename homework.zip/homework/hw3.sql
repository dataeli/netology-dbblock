SELECT 'ФИО: Атаев Илья';

CREATE TABLE links_parted (movieid bigint, imdbid varchar, tmdbid varchar);
CREATE TABLE links_parted_odd (CHECK (movieid % 2 <> 0)) INHERITS (links_parted);
CREATE RULE links_insert_odd AS ON INSERT TO links_parted WHERE (  movieid % 2 <> 0 ) DO INSTEAD INSERT INTO links_parted_odd VALUES ( NEW.*);
CREATE TABLE links_parted_even (CHECK (movieid % 2 = 0)) INHERITS (links_parted);
CREATE RULE links_insert_even AS ON INSERT TO links_parted WHERE (  movieid % 2 = 0 ) DO INSTEAD INSERT INTO links_parted_even VALUES ( NEW.*);
INSERT INTO links_parted (SELECT * FROM links WHERE movieid IS NOT NULL);