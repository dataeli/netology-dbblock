SELECT ('ФИО: Атаев Илья')
-- Служебные функции БД
SELECT relname FROM pg_class ORDER BY relpages DESC LIMIT 5;

-- Специфические функции postgres

SELECT userID, array_agg(movieId) as user_views FROM ratings GROUP BY userid;
DROP TABLE IF EXISTS user_movies_agg;
SELECT userID, user_views INTO public.user_movies_agg FROM (SELECT userID, array_agg(movieId) as user_views FROM ratings GROUP BY userid) as TMPTABLE;
SELECT * FROM user_movies_agg LIMIT 3;

-- Используя следующий синтаксис, создайте функцию cross_arr оторая принимает на вход два массива arr1 и arr2.
-- Функциия возвращает массив, который представляет собой пересечение контента из обоих списков.
-- Примечание - по именам к аргументам обращаться не получится, придётся делать через $1 и $2.

CREATE OR REPLACE FUNCTION cross_arr(int[], int[]) RETURNS int[] as 
$$
SELECT ARRAY( SELECT UNNEST($1) INTERSECT SELECT UNNEST($2));
$$ language sql;

-- Сформируйте запрос следующего вида: достать из таблицы всевозможные наборы u1, r1, u2, r2.
-- u1 и u2 - это id пользователей, r1 и r2 - соответствующие массивы рейтингов
-- ПОДСКАЗКА: используйте CROSS JOIN
WITH u2r2 AS
(SELECT * FROM user_movies_agg LIMIT 50)
SELECT user_movies_agg.userId as u1, user_movies_agg.user_views as ar1, u2r2.userid as u2, u2r2.user_views as ar2 FROM user_movies_agg CROSS JOIN u2r2 LIMIT 50;

-- Оберните запрос в CTE и примените к парам <ar1, ar2> функцию CROSS_ARR, которую вы создали
-- вы получите триплеты u1, u2, crossed_arr
-- созхраните результат в таблицу common_user_views
DROP TABLE IF EXISTS common_user_views;
WITH user_pairs as 
(WITH u2r2 AS
(SELECT * FROM user_movies_agg LIMIT 50)
SELECT user_movies_agg.userId as u1, user_movies_agg.user_views as ar1, u2r2.userid as u2, u2r2.user_views as ar2 FROM user_movies_agg CROSS JOIN u2r2 LIMIT 50
)
SELECT u1, u2, cross_arr(ar1, ar2) as cross_views INTO public.common_user_views FROM user_pairs;

-- Оставить как есть - это просто SELECT из таблички common_user_views для контроля результата
SELECT * FROM common_user_views LIMIT 3;

-- Создайте по аналогии с cross_arr функцию diff_arr, которая вычитает один массив из другого.
-- Подсказка: используйте оператор SQL EXCEPT.
CREATE OR REPLACE FUNCTION diff_arr(int[], int[]) RETURNS int[] as 
$$
SELECT ARRAY( SELECT UNNEST($1) EXCEPT SELECT UNNEST($2));
$$ language sql;

-- Сформируйте рекомендации - для каждой пары посоветуйте для u1 контент, который видел u2, но не видел u1 (в виде массива).
-- Подсказка: нужно заджойнить user_movies_agg и common_user_views и применить вашу функцию diff_arr к соответствующим полям.
-- с векторами фильмов

WITH recommends as 
(SELECT user_movies_agg.userId as user, user_movies_agg.user_views as ar1, common_user_views.u1 as u21, common_user_views.u2 as u22, common_user_views.cross_views as cv 
	FROM user_movies_agg CROSS JOIN common_user_views
)
SELECT user, array_agg(diff_arr(ar1, cv)) as recomendations FROM recommends GROUP BY u1 LIMIT 10;
