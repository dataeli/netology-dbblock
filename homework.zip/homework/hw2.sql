SELECT 'ФИО: Атаев Илья';
--Оконные функции
SELECT userId, movieId, (rating - MIN(rating) OVER (PARTITION BY userId)) / (MAX(rating) OVER (PARTITION BY userId) - MIN(rating) OVER (PARTITION BY userId)) as normed_rating,
       AVG(rating) OVER (PARTITION BY userId) as avg_rating
       FROM (SELECT DISTINCT userId, movieId, rating FROM ratings) as hmwrksql2
       ORDER BY userId LIMIT 30; 
-- ETL раздел
-- Extract
CREATE TABLE IF NOT EXISTS keywords (id bigint, tags varchar);
\\copy keywords FROM '/data/keywords.csv' DELIMITER ',' CSV HEADER;
-- Transform
-- ЗАПРОС 1 и 2
--SELECT movieId, AVG(rating) as avg_rating FROM ratings GROUP BY movieId HAVING COUNT(rating)>50 ORDER BY avg_rating DESC, movieId ASC LIMIT 150;
--WITH top_rated AS (SELECT movieId, AVG(rating) as avg_rating FROM ratings GROUP BY movieId HAVING COUNT(rating)>50 ORDER BY avg_rating DESC, movieId ASC LIMIT 150) 
 --     SELECT * FROM top_rated LEFT JOIN keywords ON top_rated.movieId=keywords.id;
-- ЗАПРОС 3
WITH top_rated AS (SELECT movieId, AVG(rating) as avg_rating FROM ratings GROUP BY movieId HAVING COUNT(rating)>50 ORDER BY avg_rating DESC, movieId ASC LIMIT 150) 
       SELECT movieId, avg_rating, tags INTO top_rated_tags FROM top_rated LEFT JOIN keywords ON top_rated.movieId=keywords.id;
-- Load
\copy top_rated_tags TO 't/data/op_rated_tags.csv' WITH CSV HEADER DELIMITER E'\t';