CREATE USER finnparnishka WITH PASSWORD 'password';
CREATE DATABASE sqlhw1;
GRANT ALL PRIVILEGES ON DATABASE sqlhw1 TO finnparnishka;
-- Создаю таблички во 2ой НФ для слайдов 15-16 (в каждой таблице получится неприводимая зависимость от ключа)
CREATE TABLE slide16_1(filmname VARCHAR(100) NOT NULL PRIMARY KEY, directorname VARCHAR(100), oskarget CHAR(1));
CREATE TABLE slide16_2(directorname VARCHAR(100) NOT NULL PRIMARY KEY, imdbrating SMALLINT);
-- Заполняю их
INSERT INTO slide16_1 VALUES ('Энни Холл','Вуди Аллен','+');
INSERT INTO slide16_1 VALUES ('Быть Джоном Малковичем','Спайк Джонс','+');
INSERT INTO slide16_1 VALUES ('Любовь и Смерть','Вуди Аллен','-');
INSERT INTO slide16_2 VALUES ('Вуди Аллен', 8);
INSERT INTO slide16_2 VALUES ('Спайк Джонс', 7);
-- Создаю таблички в 3ьей НФ для слайдов 17-18 (убираем транзитивность)
CREATE TABLE slide18_1(filmname VARCHAR(100) NOT NULL PRIMARY KEY, country VARCHAR(20));
CREATE TABLE slide18_2(country VARCHAR(20) NOT NULL PRIMARY KEY, oskarget CHAR(1));
-- Заполняю их
INSERT INTO slide18_1 VALUES ('Энни Холл','США');
INSERT INTO slide18_1 VALUES ('Быть Джоном Малковичем','США');
INSERT INTO slide18_1 VALUES ('Любовь и Смерть','Россия');
INSERT INTO slide18_2 VALUES ('США', '+');
INSERT INTO slide18_2 VALUES ('Россия', '-');
-- 
--
CREATE DATABASE sqlhw11;
GRANT ALL PRIVILEGES ON DATABASE sqlhw11 TO finnparnishka;
--
-- Создаем 3 таблички по домашнему заданию с данными из Кинопоиска
CREATE TABLE filmes(title VARCHAR(100), id INT NOT NULL PRIMARY KEY, country VARCHAR(100), box_office BIGINT, release_year TIMESTAMP);
INSERT INTO filmes VALUES ('Побег из Шоушенка',326 ,'США',59841469 ,'1994-1-1'::TIMESTAMP), ('Хулиганы',77444 ,'США',3154346 ,'2005-1-1'::TIMESTAMP), ('Скотт Пилгрим против Всех',105948 ,'США',46489927 ,'2010-1-1'::TIMESTAMP), ('Я - Легенда',195524 ,'США',585349010 ,'2007-1-1'::TIMESTAMP), ('Властелин Колец',328 ,'США',871530324 ,'2001-1-1'::TIMESTAMP);
CREATE TABLE persons(id INT NOT NULL PRIMARY KEY, fio VARCHAR(200));
INSERT INTO persons VALUES (1 ,'Том Круз'), (8 ,'Мистер Пропер'), (5 ,'Дональд Трамп'), (3 ,'Путин Вор'), (13 ,'Саша Перевозкин');
CREATE TABLE persons2content(person_id INT NOT NULL PRIMARY KEY, film_id INT NOT NULL, person_type VARCHAR(50));
INSERT INTO persons2content VALUES (1 ,326, 'режиссер'), (8 ,77444, 'актер'), (5 ,105948, 'голос улиц'), (3 ,195542, 'певец'), (13 ,328, 'актер+режиссер');